<?php
/**
 * Assisted Autocataloguing - Active Configuration
 * Generated automatically from Settings UI.
 */

return array (
  'ai' => 
  array (
    'mode' => 'cloud',
    'default_provider' => 'openai_compatible',
    'providers' => 
    array (
      'ollama' => 
      array (
        'name' => 'Ollama (Lokal)',
        'base_url' => 'http://localhost:11434',
        'model' => 'qwen3-vl:8b',
        'timeout' => 120,
      ),
      'openai_compatible' => 
      array (
        'name' => 'Cloud AI (OpenAI / OpenRouter / Gemini API)',
        'base_url' => 'http://localhost:20128/v1',
        'api_key' => 'sk-c97ea08a3559864e-08c516-20e3206e',
        'model' => 'ag/gemini-3.8-flash-medium',
        'timeout' => 60,
      ),
    ),
  ),
  'ocr' => 
  array (
    'driver' => 'auto',
    'tesseract_binary' => 'tesseract',
    'python_binary' => 'python',
    'languages' => 'ind+eng',
  ),
  'catalog' => 
  array (
    'default_provider' => 'onesearch',
  ),
  'slims' => 
  array (
    'call_number_template' => '{class} {author} {title}',
  ),
  'classification' => 
  array (
    'context_sources' => 
    array (
      0 => 'title',
      1 => 'abstract',
      2 => 'toc',
      3 => 'subjects',
    ),
  ),
);
